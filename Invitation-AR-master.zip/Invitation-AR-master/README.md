# Augmented Reality (WebAR) based Invitation Cards

Ever thought of inviting our buddies using invitation cards which are augmented reality enabled, 
so that they can view can view the content in more realistic way rather than normal printed card pattern. 
Web AR has made it more feasible since no need of application for it, we can directly go in the web app 
which we can deploy it any of the available free hosting site and view and enjoy the ar content.

Download invitation-template.jpg and start playing with the Augmented Reality content.
